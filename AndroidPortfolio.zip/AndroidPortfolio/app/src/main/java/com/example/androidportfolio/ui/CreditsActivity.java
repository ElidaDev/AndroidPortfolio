package com.example.androidportfolio.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidportfolio.R;

public class CreditsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credits);

    }
}
