package com.example.androidportfolio.ui.madlib;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.androidportfolio.R;

public class MadLibFragment extends Fragment {

    private int madlib;

    private Button madlib1, madlib2, madlib3, random;
    private EditText adjective, place, verb, color, noun, action, noun2, emotion;
    private TextView output;

    private LinearLayout layoutQuestions, layoutOutput, layoutSelection;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_madlib, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        madlib1 = view.findViewById(R.id.madlib_1);
        madlib2 = view.findViewById(R.id.madlib_2);
        madlib3 = view.findViewById(R.id.madlib_3);
        random = view.findViewById(R.id.madlib_0);
        layoutQuestions = view.findViewById(R.id.inputlayout);
        layoutOutput = view.findViewById(R.id.madlibview);
        layoutSelection = view.findViewById(R.id.madlibselection);
        adjective = view.findViewById(R.id.adjective);
        place = view.findViewById(R.id.noun);
        verb = view.findViewById(R.id.verb);
        color = view.findViewById(R.id.color);
        noun = view.findViewById(R.id.noun2);
        action = view.findViewById(R.id.action);
        noun2 = view.findViewById(R.id.noun3);
        emotion = view.findViewById(R.id.emotion);
        output = view.findViewById(R.id.outputLBL);
        Button generateBTN = view.findViewById(R.id.generateBTN);
        Button resetBTN = view.findViewById(R.id.retry);

        resetBTN.setOnClickListener(this::reset);
        generateBTN.setOnClickListener(this::generate);
        madlib1.setOnClickListener(v -> select(1));
        madlib2.setOnClickListener(v -> select(2));
        madlib3.setOnClickListener(v -> select(3));
        random.setOnClickListener(v -> select(0));

        reset(view);
    }

    public void generate(View v) {

        String adj = adjective.getText().toString();
        String plc = place.getText().toString();
        String vrb = verb.getText().toString();
        String clr = color.getText().toString();
        String n1 = noun.getText().toString();
        String act = action.getText().toString();
        String n2 = noun2.getText().toString();
        String emo = emotion.getText().toString();

        switch (madlib) {
            case 1:
                output.setText(String.format(
                        "Today was a very %s day at the %s. We went to the monkey section and saw monkeys %s on the trees. One of them had a %s %s on its head! Then, a zookeeper came by and started to %s with a big %s. Everyone laughed and felt %s.",
                        adj, plc, vrb, clr, n1, act, n2, emo));
                break;

            case 2:
                output.setText(String.format(
                        "Once upon a time in a %s land far away, there was a hidden %s filled with dragons %s all day. Their scales shimmered %s, and they guarded a magical %s. A brave hero decided to %s into the cave, carrying only a small %s. It was scary, but they felt incredibly %s.",
                        adj, plc, vrb, clr, n1, act, n2, emo));
                break;

            case 3:
                output.setText(String.format(
                        "It was a %s morning when I woke up and realized I was late for my trip to the %s. I ran outside, still %s my shoes, and tripped over a %s %s. In a panic, I tried to %s, but I only made things worse by dropping my favorite %s. I felt completely %s.",
                        adj, plc, vrb, clr, n1, act, n2, emo));
                break;
        }

        // Show output and hide inputs
        layoutOutput.setVisibility(View.VISIBLE);
        layoutQuestions.setVisibility(View.GONE);
    }

    public void reset(View v) {
        layoutSelection.setVisibility(View.VISIBLE);
        layoutOutput.setVisibility(View.GONE);
        layoutQuestions.setVisibility(View.GONE);
    }

    public void select(int selection) {

        if (selection == 0) {
            madlib = (int) (Math.random() * 3) + 1;
        } else {
            madlib = selection;
        }

        layoutSelection.setVisibility(View.GONE);
        layoutQuestions.setVisibility(View.VISIBLE);
    }
}
