package com.example.androidportfolio.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.androidportfolio.databinding.FragmentGanBinding;

public class GanFragment extends Fragment {

    private FragmentGanBinding binding;
    private int secret;
    private int strikes;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentGanBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        startNewGame(); // initialize secret + strikes

        binding.btnGuess.setOnClickListener(v -> handleGuess());
        binding.btnRestart.setOnClickListener(v -> startNewGame());
        return root;
    }

    private void startNewGame() {
        binding.imgConfetti.setVisibility(View.GONE);
        secret = (int) ((Math.random() * 100) + 1);
        strikes = 10;

        binding.tvStrikes.setText("Strikes: " + strikes);
        binding.tvFeedback.setText("Enter a number to start!");
        binding.tvScore.setText("Score: 0");
        binding.btnGuess.setEnabled(true);
    }

    private void handleGuess() {
        String guessText = binding.etGuess.getText().toString().trim();
        if (guessText.isEmpty()) {
            Toast.makeText(getContext(), "Enter a number between 1 and 100!", Toast.LENGTH_SHORT).show();
            return;
        }

        int guess = Integer.parseInt(guessText);

        if (guess == secret) {
            int score = 50 + (strikes * 5);
            binding.tvFeedback.setText("You win!");
            binding.tvScore.setText("Score: " + score);
            binding.imgConfetti.setVisibility(View.VISIBLE);
            return;
        }

        strikes--;
        binding.tvStrikes.setText("Strikes: " + strikes);

        if (guess > secret) binding.tvFeedback.setText("Too high!");
        else binding.tvFeedback.setText("Too low!");

        if (strikes == 0) {
            binding.tvFeedback.setText("Game Over!");
            binding.btnGuess.setEnabled(false);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
