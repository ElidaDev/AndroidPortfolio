package com.example.androidportfolio.ui.SciFi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.androidportfolio.R;

public class SciFIFragment extends Fragment {

    private EditText first;
    private EditText last;
    private EditText city;
    private EditText school;
    private EditText pet;
    private EditText sibling;
    private TextView output;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_scifi, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        first = view.findViewById(R.id.firstTXT);
        last = view.findViewById(R.id.lastTXT);
        city = view.findViewById(R.id.cityTXT);
        school = view.findViewById(R.id.schoolTXT);
        pet = view.findViewById(R.id.petFoodTXT);
        sibling = view.findViewById(R.id.sibcharTXT);
        output = view.findViewById(R.id.outputLBL);
        Button generatebtn = view.findViewById(R.id.generateBTN);

        generatebtn.setOnClickListener(this::generate);
    }

    public void generate(View v) {
        String sciFirstName =
                first.getText().toString().substring(0, 2) +
                        last.getText().toString().substring(0, 3);

        String sciLastName =
                city.getText().toString().substring(0, 2) +
                        school.getText().toString().substring(0, 3);

        String sciOrigin =
                pet.getText().toString() + " " +
                        sibling.getText().toString();

        output.setText(
                String.format("%s %s from the planet %s",
                        sciFirstName, sciLastName, sciOrigin)
        );
    }
}