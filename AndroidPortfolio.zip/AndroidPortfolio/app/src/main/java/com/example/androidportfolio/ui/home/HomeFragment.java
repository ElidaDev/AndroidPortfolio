package com.example.androidportfolio.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.androidportfolio.R;
import com.example.androidportfolio.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textHome;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button bioButton = view.findViewById(R.id.bioButton);
        TextView bioText = view.findViewById(R.id.bioText);
        Button hobbieButton = view.findViewById(R.id.hobbieButton);
        TextView hobbieText = view.findViewById(R.id.hobbieText);

        bioButton.setOnClickListener(v -> {
            if (bioText.getVisibility() == View.VISIBLE) {
                bioText.setVisibility(View.GONE);
                hobbieText.setVisibility(View.GONE);
                hobbieButton.setVisibility(View.GONE);
                bioButton.setText("Show Bio");
            } else {
                bioText.setVisibility(View.VISIBLE);
                hobbieButton.setVisibility(View.VISIBLE);
                bioButton.setText("Hide Bio");
            }
        });

        hobbieButton.setOnClickListener(v -> {
            if (hobbieText.getVisibility() == View.VISIBLE) {
                hobbieText.setVisibility(View.GONE);
                hobbieButton.setText("Show hobbies");
            } else {
                hobbieText.setVisibility(View.VISIBLE);
                hobbieButton.setText("Hide hobbies");
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}